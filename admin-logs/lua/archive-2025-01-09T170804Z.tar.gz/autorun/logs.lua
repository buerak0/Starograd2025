octolib.server('logs/sv_base')
octolib.server('logs/sv_loggers')

print("[LOGS] Loaded")
